token = 'YOUR_TOKEN'  # Токен бота
database_name = 'music.db'  # Файл с базой данных
shelve_name = 'shelve.db'  # Файл с хранилищем
