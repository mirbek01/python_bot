# Здесь мы подгружаем хэндлеры из файлов в текущем каталоге
from . import general_commands
from . import food
from . import drinks
from . import default_handler
