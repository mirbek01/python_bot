---
title: "Урок 14"
description: "Конечные автоматы в aiogram, разбиваем логику по файлам"
type: docs
url: "/docs/lesson_14"
BookToC: true
weight: 15
---

{{< hint warning >}}  
Эта глава отныне доступна во [второй версии книги](https://mastergroosha.github.io/telegram-tutorial-2/fsm/), 
бесплатно, без регистрации и SMS.
{{< /hint >}}